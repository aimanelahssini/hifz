"""The Hifz window: a small fixed-size prompter that slides one ayah up per key press."""

import os
import random
import subprocess
import sys

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
gi.require_version('Graphene', '1.0')
from gi.repository import Adw, Gdk, Gio, GLib, Graphene, Gtk, Pango  # noqa: E402

from . import APP_ID, quran  # noqa: E402
from .audio import RECITERS, Downloader, Player, file_for, silence  # noqa: E402
from .phonetic import STYLES, restyle  # noqa: E402
from .state import PAUSES, SPEED_MAX, SPEED_MIN, SPEEDS, State  # noqa: E402
from .translations import LANG_LABELS, available as available_langs, text as tr_text  # noqa: E402

WIDTH, HEIGHT = 440, 212
MINI = 44
PAD = 18
HEAD = 30
VIEW = HEIGHT - HEAD - PAD          # the part where the lines scroll
SLIDE_MS = 420

CSS = """
window.hifz, window.hifz.background { background: none; box-shadow: none; }
.card {
  background-color: rgba(16, 16, 20, 0.76);
  border-radius: 18px;
  border: 1px solid rgba(255, 255, 255, 0.09);
}
.head { padding: 0 10px 0 10px; min-height: 30px; }
.head label { font-size: 11px; color: rgba(255, 255, 255, 0.52); }
.head .surah { font-weight: 600; color: rgba(255, 255, 255, 0.72); }
.head button {
  min-height: 22px; min-width: 22px; padding: 2px; border-radius: 99px;
  color: rgba(255, 255, 255, 0.45); background: none; box-shadow: none;
}
.head button:hover { color: white; background: rgba(255, 255, 255, 0.10); }
.head button, .head button:focus, .head button:focus-visible { outline: none; }
.head button.on { color: white; }
.head .hide {
  color: rgba(255, 255, 255, 0.70); background: rgba(255, 255, 255, 0.10);
}
.head .hide:hover { color: white; background: rgba(255, 255, 255, 0.18); }
/* × visible on card hover; circle only when the × itself is hovered. */
.head .close {
  opacity: 0; transition: opacity 160ms ease, background 120ms ease, color 120ms ease;
  background: none;
}
.card:hover .head .close { opacity: 1; }
.head .close:hover {
  color: white; background: rgba(255, 255, 255, 0.10);
}
.mini {
  background: linear-gradient(180deg, #252b40 0%, #11131c 100%);
  border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.12);
}
.mini button.book {
  min-width: 44px; min-height: 44px; padding: 0; background: none; box-shadow: none;
  color: #e9c46a; border-radius: 12px;
}
.mini button.book:hover { color: #f6d98b; }
.count {
  font-size: 11px; font-weight: 700; color: rgba(255, 255, 255, 0.60);
  background: rgba(255, 255, 255, 0.08); border-radius: 99px; padding: 1px 8px 1px 6px;
  transition: background 300ms ease, color 300ms ease;
}
.count.zero { color: rgba(255, 255, 255, 0.32); }
.count.bump { background: rgba(120, 220, 160, 0.30); color: white; }
.line {
  font-size: 19px; font-weight: 500; letter-spacing: 0.005em;
  color: rgba(255, 255, 255, 0.56);
  transition: color 360ms ease, opacity 360ms ease;
}
.line.current { color: #ffffff; font-weight: 700; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.35); }
.line.d1 { opacity: 1; }
.line.d2 { opacity: 0.78; }
.line.d3 { opacity: 0.58; }
.line.far { opacity: 0.42; }
.line.past { opacity: 0; }
.line .ar {
  font-family: "Amiri Quran", "Amiri", "KFGQPC Uthmanic Script HAFS", "Noto Naskh Arabic", serif;
  font-size: 18px; font-weight: 400;
}
.line .ph {
  font-size: 14px; font-weight: 500; opacity: 0.85;
}
popover.settings .muted { opacity: 0.40; }
popover.settings dropdown { min-width: 160px; }
.lines { padding: 0 20px 0 18px; }
.content { transition: filter 260ms ease, opacity 260ms ease; }
.content.blurred { filter: blur(14px); opacity: 0.50; }
.finish { background: rgba(10, 10, 14, 0.45); border-radius: 18px; }
.finish .question { font-size: 17px; font-weight: 600; color: white; }
.finish .sub { font-size: 12px; color: rgba(255, 255, 255, 0.60); }
.finish button {
  border-radius: 99px; padding: 6px 18px; font-weight: 600;
  background: rgba(255, 255, 255, 0.12); color: white; box-shadow: none;
}
.finish button:hover { background: rgba(255, 255, 255, 0.20); }
.finish button.yes { background: #ffffff; color: #111114; }
.finish button.yes:hover { background: rgba(255, 255, 255, 0.86); }
.hint { font-size: 11px; color: rgba(255, 255, 255, 0.50); }
.head .pick { padding: 1px 6px; min-height: 20px; }
.head .pick label { color: rgba(255, 255, 255, 0.72); }
.head .pick .num { color: rgba(255, 255, 255, 0.45); font-weight: 600; }
.head .pick image { color: rgba(255, 255, 255, 0.40); }
.head .speed label { font-weight: 700; font-feature-settings: "tnum"; }
.head button.mode:active, .head button.mode.flash { color: white; background: rgba(255, 255, 255, 0.18); }
.finish .then { font-size: 11px; color: rgba(233, 196, 106, 0.85); }
.endhint {
  font-size: 14px; font-weight: 600; font-style: italic; color: rgba(233, 196, 106, 0.90);
  transition: opacity 360ms ease;
}
.endhint.far { opacity: 0.35; }
popover.settings > contents { padding: 12px 14px; min-width: 260px; }
popover.settings .section { font-size: 11px; font-weight: 700; color: alpha(currentColor, 0.5); }
popover.settings .sample { font-size: 12px; color: alpha(currentColor, 0.6); }
popover.dropdown > contents { padding: 6px; min-width: 0; }
popover.dropdown list { background: none; }
popover.dropdown row { border-radius: 8px; padding: 5px 8px; min-height: 0; }
popover.dropdown row .num { color: alpha(currentColor, 0.45); font-feature-settings: "tnum"; }
popover.dropdown row .done { color: alpha(currentColor, 0.45); font-size: 12px; }
popover.dropdown row.here { background: rgba(233, 196, 106, 0.16); }
popover.dropdown row.here label { font-weight: 700; }
popover.dropdown entry { margin-bottom: 6px; }
popover.dropdown row .recited { color: #7ee2a8; }
popover.dropdown .section { font-size: 11px; font-weight: 700; color: alpha(currentColor, 0.5);
  padding: 8px 8px 3px; }
popover.dropdown row button.star {
  min-height: 20px; min-width: 20px; padding: 0; background: none; box-shadow: none;
  color: alpha(currentColor, 0.55); opacity: 0; transition: opacity 120ms ease;
}
popover.dropdown row:hover button.star { opacity: 1; }
popover.dropdown list row button.star.on { opacity: 1; }
popover.dropdown list row button.star.on image,
popover.dropdown list row button.star:hover image { color: #e9c46a; }
"""


class LineView(Gtk.Box):
    def __init__(self, line, surah, state):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.add_css_class('line')
        self.line = line
        self.surah = surah
        self.primary = Gtk.Label(xalign=0, wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR,
                                 justify=Gtk.Justification.LEFT)
        self.primary.set_max_width_chars(1)
        self.primary.set_hexpand(True)
        self.append(self.primary)
        self.secondary = Gtk.Label(xalign=0, wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR,
                                   justify=Gtk.Justification.LEFT)
        self.secondary.set_max_width_chars(1)
        self.secondary.set_hexpand(True)
        self.secondary.add_css_class('ph')
        self.append(self.secondary)
        self.apply(state)

    def apply(self, state):
        if state.language == 'ph':
            # The phonetics alone, the original look.
            self.primary.remove_css_class('ar')
            self.primary.set_xalign(0)
            self.primary.set_justify(Gtk.Justification.LEFT)
            self.primary.set_direction(Gtk.TextDirection.LTR)
            self.primary.set_label(restyle(self.line.phonetic, state.phonetics))
            self.secondary.set_visible(False)
        elif state.language == 'ar':
            self.primary.set_label(self.line.arabic)
            self.primary.set_xalign(1)
            self.primary.set_justify(Gtk.Justification.RIGHT)
            self.primary.set_direction(Gtk.TextDirection.RTL)
            self.primary.add_css_class('ar')
            self.secondary.set_label(restyle(self.line.phonetic, state.phonetics))
            self.secondary.set_visible(True)
        else:
            self.primary.remove_css_class('ar')
            self.primary.set_xalign(0)
            self.primary.set_justify(Gtk.Justification.LEFT)
            self.primary.set_direction(Gtk.TextDirection.LTR)
            self.primary.set_label(tr_text(state.language, self.surah, self.line.ayah) or self.line.phonetic)
            self.secondary.set_visible(False)

    def set_distance(self, d):
        for c in ('current', 'd1', 'd2', 'd3', 'far', 'past'):
            self.remove_css_class(c)
        if d < 0:
            self.add_css_class('past')
        elif d == 0:
            self.add_css_class('current')
        elif d <= 3:
            self.add_css_class(f'd{d}')
        else:
            self.add_css_class('far')


class Prompter(Adw.ApplicationWindow):
    def __init__(self, app, state, surah):
        super().__init__(application=app, title='Hifz')
        self.state = state
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_default_size(WIDTH, HEIGHT)
        self.add_css_class('hifz')
        # Helps on X11 and some compositors when the GNOME extension isn't there.
        try:
            self.set_keep_above(True)
        except Exception:
            pass

        self.audio_on = False      # always starts muted
        self.player = Player(self._audio_ended, self._audio_next)
        self.player.set_speed(state.speed)
        self.downloads = Downloader()
        self.anim = None
        self.views = []
        self.index = 0
        self.finishing = False
        self.paused = False        # Space paused the recitation
        self._then = None
        self.scroll_acc = 0.0
        self.minimized = False
        self._lang_codes = available_langs()
        self._lang_prev = 'ph' if self.state.language == 'ar' else self.state.language

        self._build()
        self._actions()
        self._show_after()
        self.load_surah(surah)

        keys = Gtk.EventControllerKey()
        # Capture phase: space must move the text, never press a focused button.
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect('key-pressed', self._key)
        self.add_controller(keys)
        scroll = Gtk.EventControllerScroll(flags=Gtk.EventControllerScrollFlags.VERTICAL)
        scroll.connect('scroll', self._scroll)
        self.add_controller(scroll)
        click = Gtk.GestureClick(button=3)
        click.connect('pressed', self._menu_at)
        self.add_controller(click)
        self.connect('close-request', self._closing)
        self.connect('map', lambda *_: self._place_corner())

    def _place_corner(self):
        """Best-effort top-right placement when no GNOME extension is pinning us."""
        try:
            display = self.get_display()
            monitor = display.get_monitor_at_surface(self.get_surface()) if self.get_surface() else None
            if monitor is None:
                monitor = display.get_monitors().get_item(0)
            if monitor is None:
                return
            geo = monitor.get_geometry()
            margin = 12
            x = geo.x + geo.width - WIDTH - margin
            y = geo.y + margin
            # Native move works on X11; Wayland compositors may ignore it.
            if hasattr(self, 'move'):
                self.move(x, y)
            print(f'[hifz] ui: place corner ({x},{y})', flush=True)
        except Exception as e:
            print(f'[hifz] ui: place corner skipped: {e}', flush=True)

    # ---------- building ----------

    def _build(self):
        card = Gtk.Overlay()
        card.add_css_class('card')
        card.set_overflow(Gtk.Overflow.HIDDEN)
        card.set_size_request(WIDTH - 2, HEIGHT - 2)   # + 1px border on each side
        self.set_content(card)

        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.content.add_css_class('content')
        card.set_child(self.content)

        head = Gtk.Box(spacing=4)
        head.add_css_class('head')
        head.set_size_request(-1, HEAD)
        self.title = Gtk.Label(xalign=0)
        self.title.add_css_class('surah')
        self.number = Gtk.Label()
        self.number.add_css_class('num')
        pick = Gtk.Box(spacing=5)
        pick.append(self.number)
        pick.append(self.title)
        pick.append(Gtk.Image(icon_name='pan-down-symbolic', pixel_size=10))
        self.surah_pop = self._dropdown(search=True)
        self.surah_btn = Gtk.MenuButton(child=pick, popover=self.surah_pop, valign=Gtk.Align.CENTER,
                                        tooltip_text='Choose a surah')
        self.surah_btn.add_css_class('pick')
        self.surah_pop.connect('show', lambda *_: self._fill_surahs())
        self.speed_label = Gtk.Label()
        self.speed_pop = self._dropdown()
        self.speed_btn = Gtk.MenuButton(child=self.speed_label, popover=self.speed_pop,
                                        valign=Gtk.Align.CENTER, tooltip_text='Speed (← and →)')
        self.speed_btn.add_css_class('pick')
        self.speed_btn.add_css_class('speed')
        self.speed_pop.connect('show', lambda *_: self._fill_speeds())
        self.where = Gtk.Label(xalign=0)
        self.where.set_hexpand(True)
        self.where.set_ellipsize(Pango.EllipsizeMode.END)
        self.mode_btn = Gtk.Button(valign=Gtk.Align.CENTER)
        self.mode_btn.add_css_class('mode')
        self.mode_btn.connect('clicked', lambda *_: self.cycle_after())
        hide = Gtk.Button(icon_name='view-conceal-symbolic',
                          tooltip_text='Hide (leaves a small book icon) · H',
                          valign=Gtk.Align.CENTER)
        hide.add_css_class('hide')
        hide.connect('clicked', lambda *_: self.hide_to_mini())
        self.hide_btn = hide
        self.settings_pop = self._settings_popover()
        settings = Gtk.MenuButton(icon_name='emblem-system-symbolic', popover=self.settings_pop,
                                  valign=Gtk.Align.CENTER, tooltip_text='Settings')
        settings.add_css_class('gear')
        self.audio_btn = Gtk.Button(icon_name='audio-volume-muted-symbolic', valign=Gtk.Align.CENTER,
                                    tooltip_text='Recitation off (M)')
        self.audio_btn.connect('clicked', lambda *_: self.toggle_audio())
        self.spinner = Gtk.Spinner(visible=False)
        self.spinner.set_size_request(12, 12)
        count_box = Gtk.Box(spacing=3, valign=Gtk.Align.CENTER)
        count_box.add_css_class('count')
        count_box.append(Gtk.Image(icon_name='object-select-symbolic', pixel_size=10))
        self.count = Gtk.Label()
        count_box.append(self.count)
        self.count_box = count_box
        count_box.set_tooltip_text('Times you finished this surah')
        close = Gtk.Button(icon_name='window-close-symbolic', tooltip_text='Close (Ctrl+Q)',
                           valign=Gtk.Align.CENTER)
        close.add_css_class('close')
        close.connect('clicked', lambda *_: self.close())
        self.head_close = close
        for w in (self.surah_btn, self.where, settings, hide, self.spinner, self.mode_btn, self.speed_btn, self.audio_btn,
                  count_box, close):
            w.set_focusable(False)
            head.append(w)
        self.content.append(head)

        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.box.add_css_class('lines')
        self.scroller = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER,
                                           vscrollbar_policy=Gtk.PolicyType.EXTERNAL)
        self.scroller.set_size_request(-1, VIEW)
        self.scroller.set_propagate_natural_height(False)
        self.scroller.set_kinetic_scrolling(False)
        self.scroller.set_child(self.box)
        self.scroller.set_vexpand(True)
        self.scroller.set_margin_top(6)
        self.content.append(self.scroller)

        # The "did you finish?" question, over a blurred copy of the text.
        fin = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6,
                      halign=Gtk.Align.FILL, valign=Gtk.Align.FILL)
        fin.add_css_class('finish')
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6,
                        halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER, vexpand=True)
        self.question = Gtk.Label()
        self.question.add_css_class('question')
        self.sub = Gtk.Label()
        self.sub.add_css_class('sub')
        row = Gtk.Box(spacing=10, halign=Gtk.Align.CENTER)
        row.set_margin_top(10)
        no = Gtk.Button(label='Not yet')
        no.connect('clicked', lambda *_: self.answer(False))
        yes = Gtk.Button(label='Yes, I finished')
        yes.add_css_class('yes')
        yes.connect('clicked', lambda *_: self.answer(True))
        row.append(no)
        row.append(yes)
        self.then = Gtk.Label()
        self.then.add_css_class('then')
        for w in (self.question, self.sub, self.then, row):
            inner.append(w)
        fin.append(inner)
        fin.set_visible(False)
        self.finish = fin
        self.yes_btn = yes
        card.add_overlay(fin)

        # Mini book: shown when the card is hidden. Click to reopen.
        mini = Gtk.Overlay()
        mini.add_css_class('mini')
        mini.set_size_request(MINI, MINI)
        book = Gtk.Button(icon_name='accessories-dictionary-symbolic', tooltip_text='Show Hifz')
        book.add_css_class('book')
        book.set_focusable(False)
        book.connect('clicked', lambda *_: self.show_from_mini())
        mini.set_child(book)
        mini.set_visible(False)
        card.add_overlay(mini)
        self.mini = mini
        self.card = card

    def _actions(self):
        speed = Gio.SimpleAction.new_stateful('speed', GLib.VariantType('s'),
                                              GLib.Variant('s', fmt_speed(self.state.speed)))
        speed.connect('activate', self._set_speed)
        self.add_action(speed)
        reciter = Gio.SimpleAction.new_stateful('reciter', GLib.VariantType('s'),
                                                GLib.Variant('s', self.state.reciter))
        reciter.connect('activate', self._set_reciter)
        self.add_action(reciter)
        arabic = Gio.SimpleAction.new_stateful('arabic', None, GLib.Variant('b', self.state.show_arabic))
        arabic.connect('activate', self._toggle_arabic)
        self.add_action(arabic)
        auto = Gio.SimpleAction.new_stateful('auto', None, GLib.Variant('b', self.state.auto))
        auto.connect('activate', self._toggle_auto)
        self.add_action(auto)
        pause = Gio.SimpleAction.new_stateful('pause', GLib.VariantType('s'), GLib.Variant('s', self.state.pause))
        pause.connect('activate', self._set_pause)
        self.add_action(pause)
        reminder = Gio.SimpleAction.new_stateful('reminder', None, GLib.Variant('b', reminder_on()))
        reminder.connect('activate', self._toggle_reminder)
        self.add_action(reminder)
        audio = Gio.SimpleAction.new_stateful('audio', None, GLib.Variant('b', False))
        audio.connect('activate', lambda *_: self.toggle_audio())
        self.add_action(audio)
        for name, cb in (('restart', lambda *_: self.go(0, slow=True)),
                         ('hide', lambda *_: self.hide_to_mini()),
                         ('close', lambda *_: self.close())):
            a = Gio.SimpleAction.new(name, None)
            a.connect('activate', cb)
            self.add_action(a)

        menu = Gio.Menu()
        speeds = Gio.Menu()
        for s in SPEEDS:
            item = Gio.MenuItem.new(f'{fmt_speed(s)}×', None)
            item.set_action_and_target_value('win.speed', GLib.Variant('s', fmt_speed(s)))
            speeds.append_item(item)
        menu.append_section('Speed', speeds)
        opts = Gio.Menu()
        opts.append('Recitation', 'win.audio')
        reciters = Gio.Menu()
        for rid, rname in RECITERS:
            item = Gio.MenuItem.new(rname, None)
            item.set_action_and_target_value('win.reciter', GLib.Variant('s', rid))
            reciters.append_item(item)
        opts.append_submenu('Reciter', reciters)
        opts.append('Continue automatically', 'win.auto')
        breaths = Gio.Menu()
        for key, label in (('none', 'None'), ('short', 'Short breath'), ('long', 'Long breath')):
            item = Gio.MenuItem.new(label, None)
            item.set_action_and_target_value('win.pause', GLib.Variant('s', key))
            breaths.append_item(item)
        opts.append_submenu('Pause between ayahs', breaths)
        opts.append('Arabic', 'win.arabic')
        opts.append(f'Remind me at 22:00 ({quran.name(56)})', 'win.reminder')
        menu.append_section(None, opts)
        end = Gio.Menu()
        end.append('Hide', 'win.hide')
        end.append('Back to the beginning', 'win.restart')
        end.append('Close', 'win.close')
        menu.append_section(None, end)
        self.menu = Gtk.PopoverMenu.new_from_model(menu)
        self.menu.set_parent(self.get_content())
        self.menu.set_has_arrow(False)

    # ---------- surah and lines ----------

    def load_surah(self, n):
        if self.anim:
            self.anim.pause()
        self.player.halt()
        self.surah = n
        self.state.surah = n
        self.lines = quran.lines(n)
        child = self.box.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.box.remove(child)
            child = nxt
        self.views = [LineView(line, n, self.state) for line in self.lines]
        for v in self.views:
            self.box.append(v)
        # Under the last ayah: what to do once you get there.
        self.endhint = Gtk.Label(label='Finished? Press Space or scroll', xalign=0)
        self.endhint.add_css_class('endhint')
        self.box.append(self.endhint)
        spacer = Gtk.Box()
        spacer.set_size_request(-1, VIEW)          # lets the last line slide to the top
        self.box.append(spacer)
        self.title.set_label(quran.name(n))
        self.number.set_label(str(n))
        self.index = min(self.state.line(n), len(self.lines) - 1)
        self._hide_finish()
        self._refresh()
        self.state.save()
        # Jump (no slide) once the new lines have their size.
        GLib.idle_add(self._snap)

        if self.audio_on:
            self._prefetch_all()
            if not self.paused:
                self._play_current()

    def _snap(self):
        y = self._y(self.index)
        if y is None:
            GLib.timeout_add(16, self._snap)
            return GLib.SOURCE_REMOVE
        self.scroller.get_vadjustment().set_value(y)
        return GLib.SOURCE_REMOVE

    def _y(self, i):
        ok, p = self.views[i].compute_point(self.box, Graphene.Point())
        if not ok or self.views[i].get_height() == 0:
            return None
        return p.y

    def _refresh(self):
        for k, v in enumerate(self.views):
            v.set_distance(k - self.index)
        line = self.lines[self.index]
        total = quran.SURAHS[self.surah - 1][1]
        self.where.set_label(f'  ·  {line.ayah} / {total}' if line.ayah else '  ·  Bismillah')
        last = len(self.lines) - 1
        (self.endhint.remove_css_class if last - self.index <= 3 else self.endhint.add_css_class)('far')
        self.speed_label.set_label(f'{fmt_speed(self.state.speed)}×')
        n = self.state.finished(self.surah)
        self.count.set_label(str(n))
        (self.count_box.add_css_class if n == 0 else self.count_box.remove_css_class)('zero')

    def _slide_to(self, y, ms=SLIDE_MS):
        adj = self.scroller.get_vadjustment()
        if self.anim:
            self.anim.pause()
        target = Adw.CallbackAnimationTarget.new(adj.set_value)
        self.anim = Adw.TimedAnimation.new(self.scroller, adj.get_value(), y, ms, target)
        self.anim.set_easing(Adw.Easing.EASE_OUT_CUBIC)
        self.anim.play()

    def go(self, i, slow=False, play=True):
        i = max(0, min(i, len(self.lines) - 1))
        self.index = i
        self.state.set_line(self.surah, i)
        self.state.save()
        self._refresh()
        y = self._y(i)
        if y is not None:
            self._slide_to(y, 700 if slow else SLIDE_MS)
        if self.audio_on and play and not self.paused:
            self._play_current()
        elif self.paused:
            self.player.halt()

    def next(self):
        if self.finishing:
            return
        # A long ayah taller than the window scrolls inside itself first.
        adj = self.scroller.get_vadjustment()
        view = self.views[self.index]
        top = self._y(self.index) or 0
        bottom = top + view.get_height()
        shown = self.anim.get_value_to() if self.anim and self.anim.get_state() == Adw.AnimationState.PLAYING else adj.get_value()
        if bottom > shown + VIEW - 8:
            self._slide_to(min(shown + VIEW * 0.7, bottom - VIEW * 0.5))
            return
        if self.index >= len(self.lines) - 1:
            self._ask_finish()
            return
        self.go(self.index + 1)

    def move(self, step):
        # Moving by hand ends a pause: the ayah you land on is recited.
        self.paused = False
        step()

    def space(self):
        """With the recitation on, Space pauses and plays. At the last ayah, and with the sound
        off, it moves on as before."""
        last = self.index >= len(self.lines) - 1
        if not self.audio_on or last:
            self.next()
        elif self.paused:
            self.paused = False
            if self.player.playing:
                self.player.resume()
            else:
                self._play_current()
        elif self.player.playing:
            self.paused = True
            self.player.pause()
        else:
            self.next()            # this ayah is over: on to the next one

    def prev(self):
        if self.finishing:
            self._hide_finish()
            return
        adj = self.scroller.get_vadjustment()
        top = self._y(self.index) or 0
        if adj.get_value() > top + 4:
            self._slide_to(max(top, adj.get_value() - VIEW * 0.7))
            return
        if self.index > 0:
            self.go(self.index - 1)

    # ---------- finishing ----------

    def _ask_finish(self):
        self.finishing = True
        self.player.halt()
        self.question.set_label(f'Finished {quran.name(self.surah)}?')
        n = self.state.finished(self.surah)
        self.sub.set_label('It will count as your first time' if n == 0 else
                           f'Finished {n} time{"s" if n != 1 else ""} so far')
        self._then = self._after_surah()
        self.then.set_label('Then from the start' if self._then == self.surah else
                            f'Then {self._then} {quran.name(self._then)}')
        self.content.add_css_class('blurred')
        self.finish.set_visible(True)
        self.yes_btn.grab_focus()

    def _after_surah(self):
        """The surah that follows a finished one, as the end button says."""
        n, mode = self.surah, self.state.after
        if mode == 'next':
            return n % 114 + 1
        if mode == 'previous':
            return (n - 2) % 114 + 1
        if mode == 'shuffle':
            # Among your saved surahs when you have a few, otherwise any.
            pool = [k for k in self.state.saved if k != n]
            if len(pool) < 2:
                pool = [k for k in range(1, 115) if k != n]
            return random.choice(pool)
        return n

    AFTER = {
        'repeat': ('media-playlist-repeat-symbolic', 'At the end: start again'),
        'next': ('go-next-symbolic', 'At the end: the next surah'),
        'previous': ('go-previous-symbolic', 'At the end: the previous surah'),
        'shuffle': ('media-playlist-shuffle-symbolic', 'At the end: a random surah'),
    }

    def _show_after(self):
        icon, text = self.AFTER[self.state.after]
        self.mode_btn.set_icon_name(icon)
        self.mode_btn.set_tooltip_text(text)

    def cycle_after(self):
        modes = list(self.AFTER)
        self.state.after = modes[(modes.index(self.state.after) + 1) % len(modes)]
        self.state.save()
        self._show_after()
        # Say it once in the header, where the ayah number is.
        short = {'repeat': 'then again', 'next': 'then the next', 'previous': 'then the previous',
                 'shuffle': 'then random'}
        self.where.set_label('  ·  ' + short[self.state.after])
        self.mode_btn.add_css_class('flash')
        if getattr(self, '_flash_id', 0):
            GLib.source_remove(self._flash_id)

        def back():
            self._flash_id = 0
            self.mode_btn.remove_css_class('flash')
            self._refresh()
            return GLib.SOURCE_REMOVE
        self._flash_id = GLib.timeout_add(1600, back)

    def _hide_finish(self):
        self.finishing = False
        self.content.remove_css_class('blurred')
        self.finish.set_visible(False)

    def answer(self, yes):
        self._hide_finish()
        if not yes:
            return
        self.state.add_finish(self.surah)
        self.state.save()
        # Nothing plays by itself: it waits on the first line until you go on.
        self.player.halt()
        self.paused = True
        nxt = self._then
        if nxt != self.surah:
            self.state.set_line(nxt, 0)
            self.load_surah(nxt)
        else:
            self.go(0, slow=True)
        self.count_box.add_css_class('bump')
        GLib.timeout_add(900, lambda: self.count_box.remove_css_class('bump') or GLib.SOURCE_REMOVE)

    # ---------- audio ----------

    def toggle_audio(self):
        self.audio_on = not self.audio_on
        self.lookup_action('audio').set_state(GLib.Variant('b', self.audio_on))
        self.paused = False
        if self.audio_on:
            self.player.start()
            self.player.set_speed(self.state.speed)
            self.audio_btn.set_icon_name('audio-volume-high-symbolic')
            self.audio_btn.add_css_class('on')
            self.audio_btn.set_tooltip_text('Recitation on (M)')
            self._prefetch_all()
            self._play_current()
        else:
            self.player.stop()     # the whole pipeline goes away: no sound at all
            self.audio_btn.set_icon_name('audio-volume-muted-symbolic')
            self.audio_btn.remove_css_class('on')
            self.audio_btn.set_tooltip_text('Recitation off (M)')
            self._loading(False)

    def _play_current(self):
        self.player.halt()
        want = (self.state.reciter, self.surah, self.lines[self.index].ayah)
        self._want = want

        def ready(path):
            if not self.audio_on or self._want != want:
                return
            self._loading(False)
            if path:
                self.audio_btn.set_icon_name('audio-volume-high-symbolic')
                self.audio_btn.set_tooltip_text('Recitation on (M)')
                self.player.play(path)
                self._queue_next()
            else:
                # No connection, or the server is down: say so on the speaker.
                self.audio_btn.set_icon_name('network-offline-symbolic')
                self.audio_btn.set_tooltip_text("Couldn't download this ayah's recitation")
        self._loading(True)
        self.downloads.fetch(*want, done=ready, urgent=True)

    def _prefetch_all(self):
        for line in self.lines[self.index:] + self.lines[:self.index]:
            self.downloads.fetch(self.state.reciter, self.surah, line.ayah)

    def _loading(self, on):
        # Only show the spinner if the file takes a moment.
        if getattr(self, '_spin_id', 0):
            GLib.source_remove(self._spin_id)
            self._spin_id = 0
        if on:
            def show():
                self._spin_id = 0
                self.spinner.set_visible(True)
                self.spinner.start()
                return GLib.SOURCE_REMOVE
            self._spin_id = GLib.timeout_add(250, show)
        else:
            self.spinner.stop()
            self.spinner.set_visible(False)

    def _queue_next(self):
        """With "continue automatically", line up the next ayah, after a short breath (or none),
        so the recitation goes on without the player stopping in between."""
        self.player.queued = []
        if self.audio_on and self.state.auto and self.index + 1 < len(self.lines):
            path, _ = file_for(self.state.reciter, self.surah, self.lines[self.index + 1].ayah)
            if os.path.exists(path):
                breath = PAUSES[self.state.pause]
                self.player.queued = ([silence(breath)] if breath else []) + [path]

    def _audio_next(self):
        # The queued ayah has started playing: move the text along with it.
        if self.finishing or self.index + 1 >= len(self.lines):
            return
        self.go(self.index + 1, play=False)
        self._queue_next()

    def _audio_ended(self):
        if not (self.audio_on and self.state.auto) or self.finishing:
            return
        if self.index >= len(self.lines) - 1:
            self._ask_finish()
        else:
            self.go(self.index + 1)

    # ---------- menu actions ----------

    def _set_speed(self, action, value):
        self.set_speed(float(value.get_string()))

    def set_speed(self, speed):
        """Any speed from 0.5x to 2x, in steps of 0.05; it is saved for next time."""
        speed = round(min(SPEED_MAX, max(SPEED_MIN, speed)) * 20) / 20
        self.state.speed = speed
        self.state.save()
        self.player.set_speed(speed)
        self.lookup_action('speed').set_state(GLib.Variant('s', fmt_speed(speed)))
        self.speed_label.set_label(f'{fmt_speed(speed)}×')

    # ---------- dropdowns ----------

    def _dropdown(self, search=False):
        pop = Gtk.Popover(has_arrow=False)
        pop.add_css_class('dropdown')
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        pop.entry = None
        if search:
            pop.entry = Gtk.SearchEntry(placeholder_text='Number or name')
            box.append(pop.entry)
        pop.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        pop.list.set_activate_on_single_click(True)
        pop.scroll = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER,
                                        propagate_natural_height=True, max_content_height=300)
        pop.scroll.set_child(pop.list)
        box.append(pop.scroll)
        pop.set_child(box)
        # Give the keyboard back to the card, without a focus ring on the header button.
        pop.connect('closed', lambda *_: GLib.idle_add(lambda: self.set_focus(None) or False))
        return pop

    def _rows(self, pop, items, current, on_pick):
        """Fill a dropdown with (value, [labels]) rows and scroll to the current one."""
        pop.list.remove_all()
        here = None
        for value, labels in items:
            row = Gtk.ListBoxRow()
            row.value = value
            line = Gtk.Box(spacing=10)
            for text, cls, expand in labels:
                lab = Gtk.Label(label=text, xalign=1 if cls == 'num' else 0, hexpand=expand)
                if cls:
                    lab.add_css_class(cls)
                if cls == 'num':
                    lab.set_width_chars(3)
                line.append(lab)
            row.set_child(line)
            if value == current:
                row.add_css_class('here')
                here = row
            pop.list.append(row)
        if getattr(pop, 'handler', None):
            pop.list.disconnect(pop.handler)
        pop.handler = pop.list.connect('row-activated', lambda _l, row: (pop.popdown(), on_pick(row.value)))

        def scroll():
            if here is not None:
                ok, p = here.compute_point(pop.list, Graphene.Point())
                if ok:
                    adj = pop.scroll.get_vadjustment()
                    adj.set_value(max(0, p.y - adj.get_page_size() / 2 + here.get_height() / 2))
            return GLib.SOURCE_REMOVE
        GLib.idle_add(scroll)

    def _fill_surahs(self, keep_scroll=False):
        """Saved surahs first, then all 114. Finished ones are green; a star saves one."""
        pop = self.surah_pop
        adj = pop.scroll.get_vadjustment()
        top = adj.get_value()
        pop.list.remove_all()
        here = None
        rows = [(n, 'saved') for n in self.state.saved] + [(n, 'all') for n in range(1, 115)]
        for n, section in rows:
            row = Gtk.ListBoxRow()
            row.value, row.section = n, section
            line = Gtk.Box(spacing=10)
            num = Gtk.Label(label=str(n), xalign=1, width_chars=3)
            num.add_css_class('num')
            name = Gtk.Label(label=quran.name(n), xalign=0, hexpand=True)
            done = self.state.finished(n)
            if done:
                name.add_css_class('recited')
            count = Gtk.Label(label=f'✓{done}' if done else '')
            count.add_css_class('done')
            saved = n in self.state.saved
            star = Gtk.Button(icon_name='starred-symbolic' if saved else 'non-starred-symbolic',
                              tooltip_text='Remove from saved' if saved else 'Save', focusable=False)
            star.add_css_class('star')
            if saved:
                star.add_css_class('on')
            star.connect('clicked', lambda _b, n=n: self._toggle_saved(n))
            for w in (num, name, count, star):
                line.append(w)
            row.set_child(line)
            if n == self.surah and (section == 'all' or here is None):
                row.add_css_class('here')
                if section == 'all':
                    here = row
            pop.list.append(row)
        pop.list.set_header_func(self._section_header if self.state.saved else None)
        if getattr(pop, 'handler', None):
            pop.list.disconnect(pop.handler)
        pop.handler = pop.list.connect('row-activated', lambda _l, row: (pop.popdown(), self._pick_surah(row.value)))

        def scroll():
            if keep_scroll:
                adj.set_value(top)
            elif self.state.saved:
                adj.set_value(0)       # your saved surahs first
            elif here is not None:
                ok, p = here.compute_point(pop.list, Graphene.Point())
                if ok:
                    adj.set_value(max(0, p.y - adj.get_page_size() / 2 + here.get_height() / 2))
            return GLib.SOURCE_REMOVE
        GLib.idle_add(scroll)
        if keep_scroll:
            return
        entry = pop.entry
        entry.set_text('')
        if not getattr(entry, 'wired', False):
            entry.wired = True
            entry.connect('search-changed', lambda e: pop.list.invalidate_filter())
            entry.connect('activate', lambda e: self._pick_first())
            entry.connect('stop-search', lambda e: pop.popdown())
            pop.list.set_filter_func(self._match)
        GLib.idle_add(lambda: entry.grab_focus() and False)

    def _section_header(self, row, before):
        if before is None or before.section != row.section:
            label = Gtk.Label(label='Saved' if row.section == 'saved' else 'All surahs', xalign=0)
            label.add_css_class('section')
            row.set_header(label)
        else:
            row.set_header(None)

    def _toggle_saved(self, n):
        self.state.toggle_saved(n)
        self.state.save()
        self._fill_surahs(keep_scroll=True)

    def _match(self, row):
        q = self.surah_pop.entry.get_text().strip()
        if not q:
            return True
        if row.section == 'saved':
            return False           # while searching, each surah once
        if q.isdigit():
            return str(row.value).startswith(q)
        from .cli import plain
        q = plain(q).rstrip('h')
        return q in plain(quran.name(row.value))

    def _pick_first(self):
        row = self.surah_pop.list.get_first_child()
        while row is not None and not (row.get_mapped() and row.get_child_visible()):
            row = row.get_next_sibling()
        if row is not None:
            self.surah_pop.popdown()
            self._pick_surah(row.value)

    def _pick_surah(self, n):
        if n != self.surah:
            self.load_surah(n)

    def _fill_speeds(self):
        steps = [round(SPEED_MIN + k * 0.05, 2) for k in range(int((SPEED_MAX - SPEED_MIN) / 0.05) + 1)]
        items = [(v, [(f'{fmt_speed(v)}×', None, True)]) for v in steps]
        self._rows(self.speed_pop, items, round(self.state.speed, 2), self.set_speed)

    def _set_reciter(self, action, value):
        action.set_state(value)
        self.state.reciter = value.get_string()
        self.state.save()
        if self.audio_on:
            self._prefetch_all()
            self._play_current()

    def _toggle_arabic(self, action, _):
        # A key / menu: jump to Arabic, or back to the last literal language.
        if self.state.language == 'ar':
            self.set_language(self._lang_prev)
        else:
            self._lang_prev = self.state.language
            self.set_language('ar')

    def _settings_popover(self):
        pop = Gtk.Popover(has_arrow=False)
        pop.add_css_class('settings')
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)

        lang_title = Gtk.Label(label='Language', xalign=0)
        lang_title.add_css_class('section')
        box.append(lang_title)
        labels = [LANG_LABELS[c] for c in self._lang_codes]
        self.lang_drop = Gtk.DropDown.new_from_strings(labels)
        try:
            self.lang_drop.set_selected(self._lang_codes.index(self.state.language))
        except ValueError:
            self.lang_drop.set_selected(0)
        self.lang_drop.connect('notify::selected', self._lang_picked)
        box.append(self.lang_drop)

        self.tr_title = Gtk.Label(label='Transliteration', xalign=0)
        self.tr_title.add_css_class('section')
        self.tr_title.set_margin_top(4)
        box.append(self.tr_title)
        self.tr_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        styles = Gtk.Box(spacing=0)
        styles.add_css_class('linked')
        group = None
        self.style_btns = {}
        for sid, (label, _) in STYLES.items():
            b = Gtk.ToggleButton(label=label, group=group)
            group = group or b
            b.set_active(sid == self.state.phonetics)
            b.connect('toggled', lambda btn, sid=sid: btn.get_active() and self.set_phonetics(sid))
            styles.append(b)
            self.style_btns[sid] = b
        self.tr_box.append(styles)
        self.style_sample = Gtk.Label(xalign=0)
        self.style_sample.add_css_class('sample')
        self.tr_box.append(self.style_sample)
        box.append(self.tr_box)

        pop.set_child(box)
        pop.connect('show', lambda *_: print('[hifz] ui: open settings', flush=True))
        self._sample_style()
        self._sync_tr_enabled()
        return pop

    def _lang_picked(self, drop, _):
        i = drop.get_selected()
        if i < 0 or i >= len(self._lang_codes):
            return
        self.set_language(self._lang_codes[i])

    def _sample_style(self):
        self.style_sample.set_label(restyle("Idhâ waqa'ati-l-wâqi'ah · Qoul houwa-llâhou", self.state.phonetics))

    def _sync_tr_enabled(self):
        on = self.state.language in ('ph', 'ar')
        self.tr_box.set_sensitive(on)
        if on:
            self.tr_box.remove_css_class('muted')
            self.tr_title.remove_css_class('muted')
        else:
            self.tr_box.add_css_class('muted')
            self.tr_title.add_css_class('muted')

    def set_language(self, lang):
        if lang not in self._lang_codes:
            return
        if lang == self.state.language:
            self._sync_lang_ui()
            return
        if self.state.language != 'ar':
            self._lang_prev = self.state.language
        print(f'[hifz] settings: language {lang}', flush=True)
        self.state.language = lang
        self.state.save()
        for v in self.views:
            v.apply(self.state)
        self._sync_lang_ui()
        self._sync_tr_enabled()
        act = self.lookup_action('arabic')
        if act:
            act.set_state(GLib.Variant('b', lang == 'ar'))
        GLib.idle_add(self._snap)

    def _sync_lang_ui(self):
        try:
            i = self._lang_codes.index(self.state.language)
        except ValueError:
            i = 0
        if self.lang_drop.get_selected() != i:
            self.lang_drop.set_selected(i)

    def set_phonetics(self, style):
        if self.state.language not in ('ph', 'ar'):
            return
        if style == self.state.phonetics:
            return
        print(f'[hifz] settings: phonetics {style}', flush=True)
        self.state.phonetics = style
        self.state.save()
        for v in self.views:
            v.apply(self.state)
        self._sample_style()
        GLib.idle_add(self._snap)


    def _toggle_reminder(self, action, _):
        on = not action.get_state().get_boolean()
        try:
            subprocess.run(['systemctl', '--user', 'enable' if on else 'disable', '--now', TIMER],
                           check=True, capture_output=True, timeout=10)
        except (OSError, subprocess.SubprocessError):
            return
        action.set_state(GLib.Variant('b', on))

    def _set_pause(self, action, value):
        action.set_state(value)
        self.state.pause = value.get_string()
        self.state.save()
        if self.player.playing:
            self._queue_next()

    def _toggle_auto(self, action, _):
        on = not action.get_state().get_boolean()
        action.set_state(GLib.Variant('b', on))
        self.state.auto = on
        self.state.save()
        if self.player.playing:
            self._queue_next()

    def _menu_at(self, gesture, n, x, y):
        r = Gdk.Rectangle()
        r.x, r.y, r.width, r.height = int(x), int(y), 1, 1
        self.menu.set_pointing_to(r)
        self.menu.popup()


    # ---------- input ----------

    def _key(self, ctl, keyval, code, mods):
        if (self.surah_pop.get_visible() or self.speed_pop.get_visible()
                or self.settings_pop.get_visible()):
            return False           # typing in a dropdown
        # The input method can hand the same letter key over twice; act on it once.
        stamp = (keyval, ctl.get_current_event_time())

        if stamp == getattr(self, '_last_key', None):
            return True
        self._last_key = stamp
        ctrl = mods & Gdk.ModifierType.CONTROL_MASK
        if ctrl and keyval in (Gdk.KEY_q, Gdk.KEY_w):
            self.close()
            return True
        if self.minimized:
            # Any key on the mini book brings the card back (except quit above).
            self.show_from_mini()
            return True
        if self.finishing:
            if keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_y):
                self.answer(True)
            elif keyval in (Gdk.KEY_Escape, Gdk.KEY_n, Gdk.KEY_BackSpace):
                self.answer(False)
            return True
        if keyval == Gdk.KEY_space:
            self.space()
        elif keyval in (Gdk.KEY_Down, Gdk.KEY_Page_Down, Gdk.KEY_j):
            self.move(self.next)
        elif keyval in (Gdk.KEY_BackSpace, Gdk.KEY_Up, Gdk.KEY_Page_Up, Gdk.KEY_k):
            self.move(self.prev)
        elif keyval in (Gdk.KEY_Right, Gdk.KEY_plus, Gdk.KEY_KP_Add):
            self.set_speed(self.state.speed + 0.05)
        elif keyval in (Gdk.KEY_Left, Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
            self.set_speed(self.state.speed - 0.05)
        elif keyval in (Gdk.KEY_m, Gdk.KEY_M):
            self.toggle_audio()
        elif keyval in (Gdk.KEY_a, Gdk.KEY_A):
            self.activate_action('win.arabic', None)
        elif keyval in (Gdk.KEY_h, Gdk.KEY_H):
            self.hide_to_mini()
        elif keyval == Gdk.KEY_Home:
            self.go(0, slow=True)
        elif keyval == Gdk.KEY_Menu:
            self._menu_at(None, 1, WIDTH - 40, HEAD)
        else:
            return False
        return True

    # ---------- hide / mini book ----------

    def hide_to_mini(self):
        if self.minimized:
            return
        print('[hifz] ui: hide to mini', flush=True)
        self.minimized = True
        self.surah_pop.popdown()
        self.speed_pop.popdown()
        self.settings_pop.popdown()
        self.content.set_visible(False)
        self.finish.set_visible(False)
        self.mini.set_visible(True)
        self.card.set_size_request(MINI, MINI)
        self.set_default_size(MINI, MINI)

    def show_from_mini(self):
        if not self.minimized:
            return
        print('[hifz] ui: show from mini', flush=True)
        self.minimized = False
        self.mini.set_visible(False)
        self.content.set_visible(True)
        self.card.set_size_request(WIDTH - 2, HEIGHT - 2)
        self.set_default_size(WIDTH, HEIGHT)
        GLib.idle_add(self._snap)

    def _scroll(self, ctl, dx, dy):
        if self.finishing:
            return True
        unit = ctl.get_unit() if hasattr(ctl, 'get_unit') else Gdk.ScrollUnit.WHEEL
        self.scroll_acc += dy if unit == Gdk.ScrollUnit.WHEEL else dy / 40
        while self.scroll_acc >= 1:
            self.scroll_acc -= 1
            self.move(self.next)
        while self.scroll_acc <= -1:
            self.scroll_acc += 1
            self.move(self.prev)
        return True

    def _closing(self, *_):
        self.player.stop()
        self.state.save()
        return False


TIMER = 'hifz-reminder.timer'


def reminder_on():
    """Is the daily reminder's systemd timer enabled?"""
    try:
        return subprocess.run(['systemctl', '--user', 'is-enabled', TIMER], capture_output=True,
                              text=True, timeout=5).stdout.strip() == 'enabled'
    except (OSError, subprocess.SubprocessError):
        return False


def fmt_speed(s):
    return f'{s:g}'


REMINDER_SURAH = 56            # the evening reminder: Al-Wâqi'a


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.win = None

    def do_startup(self):
        Adw.Application.do_startup(self)
        Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        css = Gtk.CssProvider()
        css.load_from_string(CSS)
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), css,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        # Clicking the reminder (even with Hifz closed: GNOME starts it over D-Bus).
        open_surah = Gio.SimpleAction.new('open-surah', GLib.VariantType('i'))
        open_surah.connect('activate', lambda _a, v: self.open(v.get_int32()))
        self.add_action(open_surah)

    def open(self, surah=None):
        """Show the window: on `surah` if given, otherwise where you left off."""
        if surah is not None and not 1 <= surah <= 114:
            surah = None
        if self.win is None:
            state = State.load()
            self.win = Prompter(self, state, surah or state.surah)
            self.win.connect('destroy', lambda *_: setattr(self, 'win', None))
        elif surah and surah != self.win.surah:
            self.win.load_surah(surah)
        self.win.present()

    def do_activate(self):
        # The app grid, or GNOME starting Hifz for a notification.
        self.open()

    def remind(self):
        """The evening notification. Clicking it opens Al-Wâqi'a."""
        name = quran.name(REMINDER_SURAH)
        n = Gio.Notification.new(f'Time for {name}')
        n.set_body(f'Recite {name} before you sleep.')
        n.set_icon(Gio.ThemedIcon.new(APP_ID))
        action = f'app.open-surah({REMINDER_SURAH})'
        n.set_default_action(action)
        n.add_button('Recite now', action)
        self.send_notification('reminder', n)

    def do_command_line(self, cmd):
        args = cmd.get_arguments()[1:]
        if '--remind' in args:
            self.remind()
            if self.win is None:
                # Started only for this: let the notification go out, then quit.
                self.hold()
                GLib.timeout_add(1500, lambda: self.release() or GLib.SOURCE_REMOVE)
            return 0
        surah = None
        if '--surah' in args:
            try:
                surah = int(args[args.index('--surah') + 1])
            except (IndexError, ValueError):
                surah = None
        self.open(surah)
        return 0


def main():
    return App().run(sys.argv)
